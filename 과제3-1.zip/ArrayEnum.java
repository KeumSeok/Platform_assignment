import java.util.Scanner;
public class ArrayEnum {
    enum Command{
        ADD, LIST, SUM, AVG, STD, QUIT, INVALID ;
    }

    public static void main(String[] args){

        int index = 0;
        int values[] = new int[100];
        final Scanner scanner = new Scanner(System.in);


        while(true){

            final Command command = getCommand(scanner);
            if(command == Command.QUIT){
                System.out.println("Bye!");;
                break;
            }

            switch (command){
                case ADD:
                    final int newValue = getValue(scanner);
                    values[index] = newValue;
                    index++;
                    break;
                case LIST:
                    printList(values,index);
                    break;
                case SUM:
                    System.out.println(sum(values,index));
                    break;
                case AVG:
                    System.out.printf("%.2f%n",getAvg(values,index));
                    break;
                case STD:
                    System.out.printf("%.2f%n",getStd(values,index));
                    break;
                case INVALID:
                    System.out.println("Invalid Command");
                    break;
            }
        }
        scanner.close();
    }

    private static Command getCommand(Scanner s) {
        String str = s.next().toUpperCase();

        if (str.equals("ADD")) {
            return Command.ADD;
        }
        else if (str.equals("LIST")) {
            return Command.LIST;
        }
        else if (str.equals("AVG")) {
            return Command.AVG;
        }
        else if (str.equals("SUM")){
            return Command.SUM;
        }
        else if (str.equals("STD")){
            return Command.STD;
        }
        else if (str.equals("QUIT")){
            return Command.QUIT;
        }
        else{
            return Command.INVALID;
        }
    }

    private static int getValue(Scanner n){
        int i = n.nextInt();
        return i;
    }

    private static int sum(int arr[],int n){
        int sum=0;
        for(int i=0;i<n;i++){
            sum+=arr[i];
        }
        return sum;
    }

    private static void printList(int arr[],int n){
        for(int i=0;i<n;i++){
            System.out.print(arr[i] + " ");
        }
        System.out.print("\n");
    }

    private static double getAvg(int arr[], int n){
        double sum=0;
        for(int i=0;i<n;i++){
            sum+=arr[i];
        }
        return sum/n;
    }

    private static double getStd(int arr[], int n){
        double avg = getAvg(arr,n);
        double sum =0;

        for(int i=0;i<n;i++){
            sum+=Math.pow(arr[i]-avg,2);
        }
        sum/=n;
        return Math.sqrt(sum);
    }
}
