import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;

public class FootballClub {
    private String name;
    private final int maxSquadSize = 25;

    private ArrayList<Player> squad = new ArrayList<Player>();

    public String toString(){
        String msg = "FootballClub Name: " + name + " , Player Count: " + squad.size() + "\n" ;
        for(int i = 0; i< squad.size(); i++){
            msg+= "\t" + squad.get(i).toString() + "\n";
        }
        return msg;
    }//스쿼드 사람들 출력

    @Override
    public boolean equals(Object o ){
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FootballClub footballClub = (FootballClub) o;
        return name == footballClub.name;
    }

    @Override
    public int hashCode(){
        final int PRIME = 31;
        int result =1;
        result = PRIME * result + maxSquadSize;
        return result;
    }

    public FootballClub(String name) {
        this.name = name;
    } //생성자, 스쿼드사이즈 25고정

    public void addPlayer(Player p) {
        squad.add(p);
    }

    public void removeAllPlayer() {
        squad.clear();
    }

    public Player findPlayer(String playerFirstName, int jerseyNumber) {
        Player ins_p = new Player(playerFirstName, jerseyNumber);
        int temp = -1;
        for(int i=0; i<squad.size(); i++)
            if (squad.get(i).equals(ins_p)) temp = i;
     if (temp==-1){
         return null;
     }
     else
         return squad.get(temp);
    }

    public Command getCommand(Scanner s) {
        String str = s.next().toUpperCase();

        if (str.equals("ADD")) {
            return Command.ADD;
        }

        else if (str.equals("FIND")){
            return Command.FIND;
        }

        else if (str.equals("CLEAR")){
            return Command.CLEAR;
        }

        else if (str.equals("LIST")) {
            return Command.LIST;
        }

        else if (str.equals("QUIT")){
            return Command.QUIT;
        }

        else{
            return Command.INVALID;
        }
    }
}
