package com.cafe.menu;

import java.util.Objects;

public abstract class Beverage {
    public static final int TALL = 0;
    public static final int GRANDE = 1;
    public static final int VENTI =2;

    String name;
    int basePrice;
    int size;

    public Beverage(String name, int basePrice, int size) {
        this.name=name;
        this.basePrice=basePrice;
        this.size=size;
    }

    public String getName(){
        return this.name;
    }

    public int getbasePrice(){
        return this.basePrice;
    }

    public int getSize(){
        return this.size;
    }

    public String printSize(int size){
        if (size==0)
            return "TALL";
        else if (size ==1)
            return "GRANDE";
        else
            return "VENTI";

    }

    @Override
    public boolean equals(Object o ){
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Beverage beverage = (Beverage) o;
        return Objects.equals(name, beverage.name);
    }

   public boolean setSize(String size) {
        if ("TALL".equals(size))
            return setSize(TALL);
        else if ("GRANDE".equals(size))
            return setSize(GRANDE);
        else if ("VENTI".equals(size))
            return setSize(VENTI);
        return false;
    } //참고사항

    public boolean setSize(int size) {
        this.size=size;
        return true;
    }
}