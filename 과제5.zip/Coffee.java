package com.cafe.menu;

public class Coffee extends Beverage{
    private int defaultShot;
    public Coffee(String name){
        super(name,4100,TALL);
    }

    @Override
    public String toString(){
        return "[ name="+name+", "+"price="+(basePrice+(500*getSize()))+", "+"size="+super.printSize(size)+", ";
    }
}