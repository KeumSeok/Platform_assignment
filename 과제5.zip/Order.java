package com.cafe.order;

import java.util.ArrayList;
import java.util.List;

public class Order {
    private List<OrderItem> items = new ArrayList<OrderItem>();


    public void print() {

        for(int i = 0; i< items.size(); i++){
            System.out.println(items.get(i));
        }
        System.out.printf("Total: %,d%n", cost());
    }

    public void add(OrderItem item) {
        items.add(item);
    }

    public int cost() {
        int sum = 0;
        for(int i =0; i<items.size();i++){
            sum+=(items.get(i).quantity)*(items.get(i).beverage.getbasePrice()+(500*items.get(i).beverage.getSize())); //사이즈 바뀌는거 계산해줘야함
        }
        return sum;
    }

    public boolean setSize(String name, String size) {
        for (int i=0;i<items.size();i++){
            if(name.equals(items.get(i).beverage.getName())){
                return items.get(i).beverage.setSize(size);
            }
        }
        return false;
    }
}
