package edu.pnu.admin;

import edu.pnu.collection.GenericList;

public class FootballClub {
    private String name;
    private final int maxSquadSize = 25;

    private GenericList<Player> squad = new GenericList<Player>();


    public String toString(){
        /*String msg = "FootballClub Name: " + name + " , Player Count: " + squad.size() + "\n" ;
        for(int i = 0; i< squad.size(); i++){
            msg+= "\t" + squad.get(i).toString() + "\n";
        }
        return msg;
        GenericList GenericList*/

        String msg ="";
        System.out.println("FootballClub Name: Chelsea Player Count: "+squad.size());
            for (int i =0; i<squad.size();i++) {
                msg+=(String.valueOf(squad.get(i))+"\n");
            }
        return msg;

    }//스쿼드 사람들 출력

    @Override
    public boolean equals(Object o ){
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FootballClub footballClub = (FootballClub) o;
        return name == footballClub.name;
    }

    @Override
    public int hashCode(){
        final int PRIME = 31;
        int result =1;
        result = PRIME * result + maxSquadSize;
        return result;
    }

    public FootballClub(String name) {
        this.name = name;
    } //생성자, 스쿼드사이즈 25고정

    public void addPlayer(Player p) {
        squad.add(p);
    }

    public void removeAllPlayer() {
        squad.clear();
    }

    public Player findPlayer(String playerFirstName, int jerseyNumber) {
        Player ins_p = new Player(playerFirstName, jerseyNumber);
        int temp = -1;
        for(int i=0; i<squad.size(); i++)
            if (squad.get(i).equals(ins_p)) temp = i;
     if (temp==-1){
         return null;
     }
     else
         return squad.get(temp);
    }

}