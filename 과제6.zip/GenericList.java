package edu.pnu.collection;
import edu.pnu.admin.Player;

public class GenericList<T> {
    private static final int DEFAULT_SIZE = 10;
    private Object[] data = new Object[100];
    private int size = 0;

    public void add(T value){
        data[size++]=value;
    }

    public void clear() {
        data = new Object[100];
        size = 0;
    }

    public T get(int i) {
        return (T) data[i];
    }

    public int size() {
        return size;
    }

}
