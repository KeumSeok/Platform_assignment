package edu.pnu.admin;
import java.util.Objects;

public class Player {
    private String firstName;
    private String lastName;
    private int jerseyNumber;

    public Player(String firstName, String lastName, int jerseyNumber ) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.jerseyNumber = jerseyNumber;
    }

    public Player(String firstName,int jerseyNumber ) {
        this.firstName = firstName;
        this.jerseyNumber = jerseyNumber;
    }

    public String toString() {
        return "[" + lastName + ", " + firstName + " " + jerseyNumber+"]";
    }

    @Override
    public boolean equals(Object o ){
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Player player = (Player) o;
        return jerseyNumber == player.jerseyNumber &&
                Objects.equals(firstName, player.firstName);
    }

    @Override
    public int hashCode(){
        final int PRIME = 31;
        int result =1;
        result = PRIME * result + jerseyNumber;
        return result;
    }
}
